create definer = groot@localhost view shippers as
select (`groot`.`employees`.`EmployeeID` - 90)                                      AS `ShippersID`,
       concat(`groot`.`employees`.`FirstName`, ' ', `groot`.`employees`.`LastName`) AS `ShipperName`,
       `groot`.`employees`.`Notes`                                                  AS `Phone`
from `groot`.`employees`
where (`groot`.`employees`.`EmployeeID` >= 90);

