create
    definer = groot@localhost procedure add_customer(INOUT customerFullName varchar(255), INOUT contact varchar(255),
                                                     INOUT customerAddress varchar(255),
                                                     INOUT customerCity varchar(255), INOUT customerNo varchar(255),
                                                     INOUT customerCountry varchar(255))
begin
    insert into customers(customerid, customername, contactname, address, city, postalcode, country)
    VALUES(customerFullName, contact, customerAddress, customerCity, customerNo, customerCountry);
end;

