create
    definer = groot@localhost procedure add_shipper(INOUT shipperNo int, INOUT shipperName varchar(255),
                                                    INOUT shipperPhone text)
begin
    insert into employees(EmployeeID, FirstName, Notes)
    VALUES (shipperNo, shipperName, shipperPhone);
end;

